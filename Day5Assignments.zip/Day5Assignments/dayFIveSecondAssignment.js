var http = require("http");
var fs = require("fs");
var path = require("path");
var url=require("url");
var qs=require("querystring");

const port=3002;

var server = http.createServer((request, response) => {
    var urlObject=url.parse(request.url);

    if(request.method=="GET")
    {
        if(urlObject.pathname=="/emp"){
            var qsObject=qs.parse(urlObject.query);

            for(item of Object.keys(qsObject)  )
            {
                console.log(` ${item} : ${qsObject[item]}` );
            }
            response.end(JSON.stringify(qsObject));

            return;
        }else
        {
            response.end("")
        }
    }

    if(urlObject.pathname=="/employee"){
        if(request.method=="GET"){
            var qsObject=qs.parse(urlObject.query);

            for(item of Object.keys(qsObject)  )
            {
                console.log(` ${item} : ${qsObject[item]}` );
            }
            response.end(JSON.stringify(qsObject));

            return;
        }
    }

    if(urlObject.pathname=="/post"){
        if(request.method=="GET"){
            var qsObject=qs.parse(urlObject.query);

            for(item of Object.keys(qsObject)  )
            {
                console.log(` ${item} : ${qsObject[item]}` );
            }
            response.end(JSON.stringify(qsObject));

            return;
        }
    }

})

server.listen(port, () => {
    console.log(`Server is running at localhost with port number : ${port}`)
})