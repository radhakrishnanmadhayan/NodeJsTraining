var http = require("http");//core inbuilt module
var fs = require("fs");//core inbuilt module
var path = require("path");//core inbuilt module
var url=require("url");//core inbuilt module
var qs=require("querystring");//core inbuilt module

const port=3000;
var postsArr=[];
var server=http.createServer((request,response)=>{

    if(request.url=="/posts")
    {
        if(request.method=="DELETE")
        {
            var newPosts="";
            request.on("data",(chunks)=>{
                newPosts+=chunks;
            })

            request.on("end",()=>{

                
                var newPostsObj=JSON.parse(newPosts);
                var pos=postsArr.findIndex(item => item.postsName == newPostsObj.postsName);
                if(pos>=0)
                {
                    var delObj=postArr.splice(pos,1);
                    response.end(JSON.stringify({msg:"Successfully Deleted",delObj}));
                    //response.end(JSON.stringify({msg:"Data was Empty"}));
                }else
                {
                  // postsArr[pos].status=newPostsObj.status;
                  
                    response.end(JSON.stringify({err:"Data not exist!!"}));
                }
            })

        }
        return;
    }



})

server.listen(port,()=>{
    console.log(`Server has started at port ${port}`);
})