var prdArr=[];

//     prdArr = [
//     {"productId": 1001, "productName":"Monitor", price:20000, quantity:10, category:"computer"},
//     {"productId": 1002, "productName":"Keyboard", price:2000, quantity:5, category:"computer"},
//     {"productId": 1003, "productName":"Mouse", price:500, quantity:20, category:"computer"},
//     {"productId": 1004, "productName":"CPU", price:15000, quantity:5, category:"computer"},
//     {"productId": 1005, "productName":"Speakers", price:3000, quantity:25, category:"computer"},
//     {"productId": 1006, "productName":"Charger", price:1000, quantity:30, category:"mobile"},
//     {"productId": 1007, "productName":"Headset", price:2000, quantity:10, category:"mobile"}
// ];

function getAllProducts(request,response)
{
    return prdArr;
}

function addProduct(request,response){
    prdArr.push(request.body);
    return true;
}
module.exports={getAllProducts,addProduct}