var express=require("express");
const morgan=require("morgan");//module to be installed
const path=require("path");
// logging of the requests -- morgan
const fs=require("fs");

var productsController=require("../controllers/productsController")




var router=express.Router();

// middleware specific to products route
router.use((request,response,next)=>{
    console.log("Products routes middleware",request.rootDirName);// path to he root folder
    var wStream=fs.createWriteStream(path.join(request.rootDirName,"log","serverLog.txt"),{flags:"a"});
    morgan("short",{stream:wStream})
    wStream.close();
    next();
})

//day 8 Assignment
router.get("/",(request,response,next)=>{
    var data=productsController.getAllProducts();
    response.send(data);
 })
//day 8 assignment
 router.post("/",(request,response,next)=>{
    var status=productsController.addProduct(request,response);
    if(status)
    {
        response.send({msg:"successfull product added"});
    }else{
        response.send({msg:"error in add Product"});
    }
})

router.put("/",(request,response,next)=>{
    
})


router.delete("/",(request,response,next)=>{
    
})

module.exports=router;



